from django.shortcuts import render
from django.contrib.auth.models import User
from django.http import HttpResponse
from core.views import *
from core.views2 import *
import sqlite3
connection = sqlite3.connect("gfg.db",check_same_thread=False)
#cursor
crs = connection.cursor()




def metrics(request):
    return render(request,"metrics.html")

def guage(request):
    return render(request,"guage.html")



#AR VR

def temp(request):
    group_name="TVS"
    print("this is machine name",group_name)
    group="second"
    crs.execute("SELECT * from {} order by temp desc limit 50".format(group_name))
    r=crs.fetchall()    
    print(r)
    tep=[]
    noise=[]
    x=[]
    y=[]
    z=[]
    for i in range(len(r)):
        tep.append(r[i][0])
        noise.append(r[i][1])
        x.append(r[i][2])
        y.append(r[i][3])
        z.append(r[i][4])
        
    print(noise)
    return render(request,"ARVR/temp.html",{"groupname":group_name,"temp":temp})


def noise(request):
    group_name="TVS"
    print("this is machine name",group_name)
    group="second"
    crs.execute("SELECT * from {} order by temp desc limit 50".format(group_name))
    r=crs.fetchall()    
    print(r)
    tep=[]
    noise=[]
    x=[]
    y=[]
    z=[]
    for i in range(len(r)):
        tep.append(r[i][0])
        noise.append(r[i][1])
        x.append(r[i][2])
        y.append(r[i][3])
        z.append(r[i][4])
        
    print(noise)
    return render(request,"ARVR/noise.html",{"groupname":group_name,"noise":noise})


def x_vib(request):
    group_name="TVS"
    print("this is machine name",group_name)
    crs.execute("SELECT * from {} order by temp desc limit 50".format(group_name))
    r=crs.fetchall()    
    print(r)
    tep=[]
    noise=[]
    x=[]
    y=[]
    z=[]
    for i in range(len(r)):
        tep.append(r[i][0])
        noise.append(r[i][1])
        x.append(r[i][2])
        y.append(r[i][3])
        z.append(r[i][4])
        
    print(noise)
    return render(request,"ARVR/x_vib.html",{"groupname":group_name})


def y_vib(request,group_name):
    print("this is machine name",group_name)
    crs.execute("SELECT * from {} order by temp desc limit 50".format(group_name))
    r=crs.fetchall()    
    print(r)
    tep=[]
    noise=[]
    x=[]
    y=[]
    z=[]
    for i in range(len(r)):
        tep.append(r[i][0])
        noise.append(r[i][1])
        x.append(r[i][2])
        y.append(r[i][3])
        z.append(r[i][4])
        
    print(noise)
    return render(request,"ARVR/y_vib.html",{"groupname":group_name})


def z_vib(request,group_name):
    print("this is machine name",group_name)
    crs.execute("SELECT * from {} order by temp desc limit 50".format(group_name))
    r=crs.fetchall()    
    print(r)
    tep=[]
    noise=[]
    x=[]
    y=[]
    z=[]
    for i in range(len(r)):
        tep.append(r[i][0])
        noise.append(r[i][1])
        x.append(r[i][2])
        y.append(r[i][3])
        z.append(r[i][4])
        
    print(noise)
    return render(request,"ARVR/z_vib.html",{"groupname":group_name})


def press(request,group_name):
    print("this is machine name",group_name)
    crs.execute("SELECT * from {} order by temp desc limit 50".format(group_name))
    r=crs.fetchall()    
    print(r)
    tep=[]
    noise=[]
    x=[]
    y=[]
    z=[]
    for i in range(len(r)):
        tep.append(r[i][0])
        noise.append(r[i][1])
        x.append(r[i][2])
        y.append(r[i][3])
        z.append(r[i][4])
        
    print(noise)
    return render(request,"ARVR/press.html",{"groupname":group_name})










# def temp(request):
#     return render(request,"ARVR/temp.html")

# def temp(request):
#     return render(request,"ARVR/temp.html")

# def temp(request):
#     return render(request,"ARVR/temp.html")

def temp(request):
    return render(request,"ARVR/temp.html")

def temp(request):
    return render(request,"ARVR/temp.html")
    
    
    
    
    
def checkpont(request):
    current=request.user
    id=current.id
    print(id)
    user=User.objects.get(id=id)
    fault=user.fault_occur_set.all()
    all_user=User.objects.all()
    print("clear list",runningmachine)
    print("this is moduls handling",runningmachine)
    print("this is moduls handling",len(runningmachine))
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)
 
    conext={'faults':fault}
    return HttpResponse("hello http reponse")








def level11(request):
    
    if request.POST:
        useremail=request.POST['email']
        current_user=request.user
        id=current_user.id
        cust_id=User.objects.get(id=id)     
        print(useremail)
        print(cust_id)
        user=level1(username=cust_id,email=useremail)
        
            
        if level1.objects.filter(username=cust_id).exists():
            print("already exists")
            messages.info(request,"Email already exists")
            return redirect("alert")
        else:
            user.save()
            return redirect("alert")
        
    return redirect("alert")   
        # return HttpResponse("level1 recoreds is not save")



def level22(request):
    
    if request.POST:
        useremail=request.POST['email']
        current_user=request.user
        id=current_user.id
        cust_id=User.objects.get(id=id)     
        print(useremail)
        print(cust_id)
        user=level2(username=cust_id,email=useremail)
        
            
        if level2.objects.filter(username=cust_id).exists():
            print("already exists")
            messages.info(request,"Email already exists")
            return redirect("alert")
        else:
            user.save()
            return redirect("alert")
        
    return redirect("alert")   
    # return HttpResponse("level1 recoreds is not save11")




def level33(request):
    if request.POST:
        email=request.POST['email']
        current_user=request.user
        id=current_user.id
        cust_id=User.objects.get(id=id)     
        user=level3(username=cust_id,email=email)
        
        if level3.objects.filter(username=cust_id).exists():
            print("already exists")
            messages.info(request,"Email already exists")
            return redirect("alert")
        else:
            user.save()
            return redirect("alert")
        
    return redirect("alert")






def level44(request):
    if request.POST:
        email=request.POST['email']
        current_user=request.user
        id=current_user.id
        cust_id=User.objects.get(id=id)     
        user=level4(username=cust_id,email=email)
        
        if level4.objects.filter(username=cust_id).exists():
            print("already exists")
            messages.info(request,"Email already exists")
            return redirect("alert")
        else:
            user.save()
            return redirect("alert")
    
    
    return redirect("alert")       
 