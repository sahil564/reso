from django.urls import path
from django.urls import path
from .consumers import *

ws_urlpatterns = [
    path("ws/jwc/<str:groupname>/",OrderConsumer.as_asgi()),
    path("ws/pred/<str:groupname>/",prediction.as_asgi()),
    path("ws/guage/<str:groupname>/",guage.as_asgi()),

    
]