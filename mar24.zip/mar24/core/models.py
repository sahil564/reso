from django.db import models

from django.db import models
from django.contrib.auth.models import User

# Create your models here.


# import the standard Django Model
# from built-in library
from django.db import models


# class Customer(models.Model):
#     user=models.OneToOneField(User,null=True,on_delete=models.CASCADE)
#     name=models.CharField(max_length=200,null=True)
    
    # def __str__(self):
    #     return self.name


# declare a new model with a name "GeeksModel"
class Machine(models.Model):
        # fields of the model

    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    username = models.CharField(max_length = 200)
    # email = models.EmailField(max_length = 200)
    machine_ID = models.CharField(max_length = 200)
    machine_IDC = models.CharField(max_length = 200)
    number= models.IntegerField(blank=True, null=True)
    aimodel = models.CharField(max_length = 200)

  
    
    
 
        # renames the instances of the model
        # with their title name
    def __str__(self):
        return self.username
    
    
class Fault_occur(models.Model):
        # fields of the model
    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    machine_ID = models.ForeignKey(Machine, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)
    messages=models.CharField(max_length = 200)
    reason=models.CharField(max_length = 200)
    status=models.CharField(max_length=200,null=True)
    fault_data = models.DateTimeField(auto_now_add=True,null=True)
    fault_data_resolved = models.CharField(max_length=200,null=True)
    # machine_ID=str(machine_ID)
   # renames the instances of the model
        # with their title name
    def __str__(self):
        return str(self.machine_ID)
    
    
    
    
class Fault_future(models.Model):
        # fields of the model
    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    machine_ID = models.ForeignKey(Machine, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)
    messages=models.CharField(max_length = 200)
    reason=models.CharField(max_length = 200)
    fault_data = models.DateTimeField(auto_now_add=True,null=True)

    # machine_ID=str(machine_ID)
   # renames the instances of the model
        # with their title name
    def __str__(self):
        return str(self.machine_ID)
    
    
    
    
class Email_user(models.Model):
    # fields of the model
    customer = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    machine_ID = models.ForeignKey(Machine, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)
    messages=models.CharField(max_length = 200)
    fault_data = models.DateTimeField(auto_now_add=True,null=True)
    # machine_ID=str(machine_ID)
   # renames the instances of the model
        # with their title name
    def __str__(self):
        return self.email
    
    
    
    

class Stop_machine(models.Model):
    # fields of the model
    machine=models.CharField(max_length=200)
    fault_data = models.DateTimeField(auto_now_add=True,null=True)
    # machine_ID=str(machine_ID)
   # renames the instances of the model
        # with their title name
    def __str__(self):
        return self.machine










class Mlmodel(models.Model):
    username = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True) 
    name = models.CharField(max_length=100, null=True, blank=True)
    size = models.CharField(max_length=100, null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True,null=True)
    file = models.FileField()
    
    def __str__(self):
        return self.name
    
class time_model(models.Model):
    username = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True) 
    name = models.CharField(max_length=100, null=True, blank=True)
    size = models.CharField(max_length=100, null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True,null=True)
    file = models.FileField()
    
    def __str__(self):
        return self.name




class permission(models.Model):
    username=models.CharField(max_length=100, null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True,null=True)

    def __str__(self):
        return self.username




class newuser(models.Model):
    username=models.CharField(max_length=100, null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True,null=True)

    def __str__(self):
        return self.username








class level1(models.Model):
    # fields of the model
    username = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)

    def __str__(self):
        return self.email

class level2(models.Model):
    # fields of the model
    username = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)

    def __str__(self):
        return self.email

class level3(models.Model):
    # fields of the model
    username = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)

    def __str__(self):
        return self.email

class level4(models.Model):
    # fields of the model
    username = models.ForeignKey(User, null=True, on_delete= models.SET_NULL)
    email = models.EmailField(max_length = 200)

    def __str__(self):
        return self.email


	

