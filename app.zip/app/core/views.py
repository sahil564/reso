from django.shortcuts import render
from django.shortcuts import render
from channels.layers import get_channel_layer


import json
from .models import *
import asyncio
from core.models import *


from channels.layers import get_channel_layer

import time
from threading import Thread
from threading import Thread


# Create your views here.

import logging
import json
from trading_ig import IGService, IGStreamService
from trading_ig.config import config
from trading_ig.lightstreamer import Subscription


epic = "CS.D.BITCOIN.CFD.IP"
username = "darcos234"
password = "Darcos@123456"
demo_api_key = "ebc859beee50d2e7615bbe39e01218666e0c25b5"
acc_type = "DEMO"
acc_number = "Z4YBRT"






def Document_save(request):
    if request.method=="POST":
        audio = request.FILES["audio"]
        name = "sahil"

        return render(request,"prediction.html",)
        
    return render(request, "index.html")


def sahil(request):

    return render(request,"prediction.html",)



def home(request):
    return render(request,'real.html')



def trad(request):
    return render(request,'trad.html')



def live(request):
    return render(request,'sensor.html')











def live(request):
    return render(request,"sensor.html")




async def home1(group,msg):
    # await time.sleep(0.1)
    # time.sleep(1)
    
    
    
    
    try:
        channel_layer=get_channel_layer()
        await (channel_layer.group_send)(group,{'type':"send_order",'value':json.dumps(msg)})
    except:
        print("this is out side thread")
    # await time.sleep(.1)


def on_prices_update(item_update):
    print(type(item_update))
    
    msg=item_update['values']["BID"]+","+item_update['values']["OFR"]+","+item_update['values']["UTM"]
    print("this is type",msg)
    group='sahil'
    asyncio.run(home1(group,msg))

def on_account_update(balance_update):
    print("balance: %s " % balance_update)

def disp():
    logging.basicConfig(level=logging.INFO)
    # logging.basicConfig(level=logging.DEBUG)

    ig_service = IGService(
        username, password, demo_api_key, acc_type, acc_number
    )

    ig_stream_service = IGStreamService(ig_service)
    ig_stream_service.create_session()
    #ig_stream_service.create_session(version='3')
    
    # Making a new Subscription in MERGE mode
    subscription_prices = Subscription(
        mode="DISTINCT",
        items=["CHART:CS.D.BITCOIN.CFD.IP:TICK"], # sample CFD epics
        #items=["L1:CS.D.GBPUSD.TODAY.IP", "L1:IX.D.FTSE.DAILY.IP"], # sample spreadbet epics
        #fields=["UTM","BID_CLOSE","OFR_CLOSE","BID_HIGH","OFR_HIGH","BID_LOW","OFR_LOW","LTV","CONS_END"],
        fields=["UTM","BID","OFR","CONS_END"]
    )
    
    subscription_prices.addlistener(on_prices_update)
    

    # Registering the Subscription
    sub_key_prices = ig_stream_service.ls_client.subscribe(subscription_prices)
    '''
    subscription_prices = Subscription(
        mode = "MERGE",
        items = ["ACCOUNT:"+"Z4QXQS"],
        fields = ["PNL"]
    )
    # Adding the "on_price_update" function to Subscription
    subscription_prices.addlistener(on_prices_update)
    

    # Registering the Subscription
    sub_key_prices = ig_stream_service.ls_client.subscribe(subscription_prices)'''

    # Making an other Subscription in MERGE mode
    '''
    subscription_account = Subscription(
        mode="MERGE", items=["ACCOUNT:" + "Z4QXQS"], fields=["AVAILABLE_CASH"],
    )

    # Adding the "on_balance_update" function to Subscription
    subscription_account.addlistener(on_account_update)

    # Registering the Subscription
    sub_key_account = ig_stream_service.ls_client.subscribe(subscription_account)
    '''
    input(
        "{0:-^80}\n".format(
            "HIT CR TO UNSUBSCRIBE AND DISCONNECT FROM \
    LIGHTSTREAMER"
        )
    )

    # Disconnecting
    ig_stream_service.disconnect()



t = Thread(target=disp, args=())
t.start()
  