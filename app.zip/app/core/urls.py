from django.urls import path
from core.views import *
urlpatterns = [
    path("upload/",Document_save,name="upload"),
    path("sahil/",sahil,name="sahil"),
    path("",home,name="home"),
    path("trad/",trad,name="trad"),
    path("live",live,name="live")
]