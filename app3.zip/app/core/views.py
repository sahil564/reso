from django.shortcuts import render
from django.shortcuts import render
from channels.layers import get_channel_layer

from multiprocessing import context
from django.shortcuts import render, HttpResponse
from django.shortcuts import render, redirect 
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

from email import message
from django.shortcuts import render, redirect
from pyexpat.errors import messages
from wsgiref.util import request_uri
from django.shortcuts import render
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate
from django.contrib import messages
import pickle
from django.contrib.auth.forms import AuthenticationForm
from core.models import *
import json
from .models import *
import asyncio
from core.models import *


from channels.layers import get_channel_layer

import time
from threading import Thread
from threading import Thread


# Create your views here.

import logging
import json
from trading_ig import IGService, IGStreamService
from trading_ig.config import config
from trading_ig.lightstreamer import Subscription


epic = "CS.D.BITCOIN.CFD.IP"
username = "darcos234"
password = "Darcos@123456"
demo_api_key = "ebc859beee50d2e7615bbe39e01218666e0c25b5"
acc_type = "DEMO"
acc_number = "Z4YBRT"






def Document_save(request):
    if request.method=="POST":
        audio = request.FILES["audio"]
        name = "sahil"

        return render(request,"prediction.html",)
        
    return render(request, "index.html")


def sahil(request):

    return render(request,"prediction.html",)



def home(request):
    return render(request,'real.html')



def trad(request):
    return render(request,'trad.html')



def live(request):
    return render(request,'sensor.html')




def newdes(request):
    return render(request,"newfront.html")




def live(request):
    return render(request,"sensor.html")


def login(request):
    return render(request,"login.html")

def login(request):
    if request.method=="POST":
        form = AuthenticationForm(request,data=request.POST)
        if form.is_valid():
            username=request.POST['username']
            password=request.POST['password']
            user=authenticate(username=username,password=password)
            if user is not None:
                auth.login(request,user)
                context={'orgnization':password,
                         "username":username,}
                # return render(request,'newdes.html')
                return redirect(trad)
            else:
                messages.info(request,"Invalid Username or password")

        else:
            messages.error(request,"Invalid username or password.")


    form=AuthenticationForm
    return render(request=request,template_name="login.html")




def logout_user(request):
    auth.logout(request)
    return redirect("home1")






def register(request):
    return render(request,"register.html")



def register(request):
    if request.method=='POST':
        first_name=request.POST['first_name']
        last_name=request.POST["last_name"]
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        confirm_password=request.POST['confirm_password']
        if password==confirm_password:
            if User.objects.filter(username=username).exists():
                messages.info(request,"username is already exits")
                return redirect(register)
            else:
                user=User.objects.create(username=username,password=password,email=email,first_name=first_name,last_name=last_name)
                user.set_password(password)
                user.save()
                context={'orgnization':username,
                         "username":first_name}
                return render(request,'login.html',context)
    else:
        print("this is not post request")
        return render(request,"register.html")















def two(request):
    return render(request,"Two.html")

# async def home1(group,msg):
#     # await time.sleep(0.1)
#     # time.sleep(1)
    
    
    
    
#     try:
#         channel_layer=get_channel_layer()
#         await (channel_layer.group_send)(group,{'type':"send_order",'value':json.dumps(msg)})
#     except:
#         print("this is out side thread")
#     # await time.sleep(.1)


# def on_prices_update(item_update):
#     print(item_update)
    
#     msg=item_update['values']["BID"]+","+item_update['values']["OFR"]+","+item_update['values']["UTM"]
#     print("this is type",msg)
#     group='sahil'
#     asyncio.run(home1(group,msg))

# def on_account_update(balance_update):
#     print("balance: %s " % balance_update)

# def disp():
#     logging.basicConfig(level=logging.INFO)
#     # logging.basicConfig(level=logging.DEBUG)

#     ig_service = IGService(
#         username, password, demo_api_key, acc_type, acc_number
#     )

#     ig_stream_service = IGStreamService(ig_service)
#     ig_stream_service.create_session()
#     #ig_stream_service.create_session(version='3')
    
#     # Making a new Subscription in MERGE mode
#     subscription_prices = Subscription(
#         mode="DISTINCT",
#         items=["CHART:CS.D.BITCOIN.CFD.IP:TICK"], # sample CFD epics
#         #items=["L1:CS.D.GBPUSD.TODAY.IP", "L1:IX.D.FTSE.DAILY.IP"], # sample spreadbet epics
#         #fields=["UTM","BID_CLOSE","OFR_CLOSE","BID_HIGH","OFR_HIGH","BID_LOW","OFR_LOW","LTV","CONS_END"],
#         fields=["UTM","BID","OFR","CONS_END"]
#     )
    
#     subscription_prices.addlistener(on_prices_update)
    

#     # Registering the Subscription
#     sub_key_prices = ig_stream_service.ls_client.subscribe(subscription_prices)
#     '''
#     subscription_prices = Subscription(
#         mode = "MERGE",
#         items = ["ACCOUNT:"+"Z4QXQS"],
#         fields = ["PNL"]
#     )
#     # Adding the "on_price_update" function to Subscription
#     subscription_prices.addlistener(on_prices_update)
    

#     # Registering the Subscription
#     sub_key_prices = ig_stream_service.ls_client.subscribe(subscription_prices)'''

#     # Making an other Subscription in MERGE mode
#     '''
#     subscription_account = Subscription(
#         mode="MERGE", items=["ACCOUNT:" + "Z4QXQS"], fields=["AVAILABLE_CASH"],
#     )

#     # Adding the "on_balance_update" function to Subscription
#     subscription_account.addlistener(on_account_update)

#     # Registering the Subscription
#     sub_key_account = ig_stream_service.ls_client.subscribe(subscription_account)
#     '''
#     input(
#         "{0:-^80}\n".format(
#             "HIT CR TO UNSUBSCRIBE AND DISCONNECT FROM \
#     LIGHTSTREAMER"
#         )
#     )

#     # Disconnecting
#     ig_stream_service.disconnect()



# t = Thread(target=disp, args=())
# t.start()
  