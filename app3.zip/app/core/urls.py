from django.urls import path
from core.views import *
urlpatterns = [
    path("upload/",Document_save,name="upload"),
    path("sahil/",sahil,name="sahil"),
    path("past/",home,name="home"),
    path("trad/",trad,name="trad"),
    path("live",live,name="live"),
    path("",newdes,name="newfront"),
    path("login_user/",login,name="login_user"),
    path("register",register,name="register"),
    path("two/",two,name="two")
]