
from channels.generic.websocket import AsyncWebsocketConsumer




class OrderConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        print("Websocket connect....")
        print("channel Layer",self.channel_layer)
        print("channel Name",self.channel_name)
        # self.group_name = self.scope['url_route']['kwargs']['groupname']
        # print("group Name:",self.group_name)
        # await self.channel_layer.group_add(
        #     self.group_name,
        #     self.channel_name
        # )
        # await self.accept()

        self.group_name='sahil'
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self,close_code):
        pass

    async def receive(self,text_data):
        print (text_data)
        await self.channel_layer.group_send(
            self.group_name,
            {
                'type':'send_order',
                'value':text_data,
            }
        )

    async def send_order(self,event):
        # print ("this is event",event['value'])
        await self.send(event['value'])

