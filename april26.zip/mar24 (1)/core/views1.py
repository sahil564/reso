from multiprocessing import context
from django.shortcuts import render, HttpResponse
from django.shortcuts import render, redirect 
from django.contrib.auth.models import User
from core.models import Machine,Mlmodel
from django.contrib.auth.decorators import login_required
from core.views import *
from core.views2 import *
from email import message
from django.shortcuts import render, redirect
from pyexpat.errors import messages
from wsgiref.util import request_uri
from django.shortcuts import render
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate
from django.contrib import messages
import pickle
from django.contrib.auth.forms import AuthenticationForm
from core.models import permission as per
from core.models import *
from random import randint
# Create your views here.

def sensor(request):
    return render(request, 'base.html')
    # return HttpResponse("this is homepage")
    
def stop(request,group_name):
    print("stop_fuction",group_name)
    return render(request,"stop.html",{"groupname":group_name})


# def stop_submit(request,group_name):
#     print(group_name)
#     if Stop.objects.filter(machine = group_name).exists():
#         print("already exists")
#     # at least one object satisfying query exists
#     else:
#         user=Stop(machine=group_name)
#         user.save()
#     # Machine.objects.get(machine_ID=group_name).delete()
#     return redirect('services1')

def stop(request,group_name):
    print("stop_fuction",group_name)
    return render(request,"sensor.html",{"groupname":group_name})



def start(request,group_name):
    print("start_fuction",group_name)
    return render(request,"start.html",{"groupname":group_name})

def start_submit(request,group_name):
    print("this is submit start",group_name)
    # Stop.objects.get(machine=group_name).delete()
    # return render(request,"start.html",{"groupname":group_name})
    return redirect('services1')








def delete(request,group_name):
    print(group_name)
    # Machine.objects.get(machine_ID=group_name).delete()
    return render(request,"Mdelete.html",{"groupname":group_name})

def delete_submit(request,group_name):
    print(group_name)
    Machine.objects.get(username=group_name).delete()
    return redirect('services1')












def newd(request):

    return render(request,'bar.html')
    



def newd1(request):
    return render(request,'future.html')



def test(request):
    return render(request,'newcheck.html')



def email1(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.email_user_set.all()
    fault_N=user.email_user_set.count()
    all_user=User.objects.all()
    
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)
 
    conext={'faults':fault,'user':user,'Number_fault':fault_N}
    return render(request,"EMAIL.html",conext)

 
 
 
 
 
 
 
 
 
def fault(request):

    return render(request,"fault.html") 
  
  
    
def fault_P(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.fault_occur_set.all()
    all_user=User.objects.all()
    
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)
 
    conext={'faults':fault}
    return render(request,"fault1.html",conext)
    

def future_fault(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.fault_future_set.all()
    all_user=User.objects.all()
    
    print("future current user",user)
    print(" future all user",all_user)
    print(" future all user",fault)
 
    conext={'faults':fault}
    return render(request,"fault2.html",conext)


def machine_delete(request,machine_name):
    Machine.objects.get(machine_ID=machine_name).delete()
    
    
    
 
    
def future_prediction_chart(request):
    group_name='fireconnect'
    print("this is machine name",group_name)

    # return render(request, 'machine.html',{"groupname":group_name})
    return render(request,'futureForcating.html',{"groupname":group_name})


def future_prediction_chart(request,group_name):
    group_name=group_name
    print("this is machine name",group_name)

    # return render(request, 'machine.html',{"groupname":group_name})
    return render(request,'futureForcating.html',{"groupname":group_name})

pred=[]
low=[]
upp=[]
predn=[]
lown=[]
uppn=[]
predx=[]
lowx=[]
uppx=[]
predy=[]
lowy=[]
uppy=[]
predz=[]
lowz=[]
uppz=[]

predp=[]
lowp=[]
uppp=[]

for i in range(600):
    a=randint(30, 40)
    b=randint(60,70)
    c=randint(200,300)
    d=randint(200,300)
    e=randint(200,300)
    f=randint(60,120)
    pred.append(a)
    low.append(a-5)
    upp.append(a+5)
    predn.append(b)
    lown.append(b-5)
    uppn.append(b+5)
    predx.append(c)
    lowx.append(c-5)
    uppx.append(c+5)
    predy.append(d)
    lowy.append(d-5)
    uppy.append(d+5)
    predz.append(e)
    lowz.append(e-5)
    uppz.append(e+5)
    predp.append(f)
    lowp.append(f-5)
    uppp.append(f+5)



def future_prediction_chart_hours(request,group_name):

    
    group_name=group_name
    print("this is machine name",group_name)

    # return render(request, 'machine.html',{"groupname":group_name})
    return render(request,'futureForcastingH.html',{"groupname":group_name,"pred":pred,"low":low,"upp":upp,"predn":predn,"lown":lown,"uppn":uppn,"predx":predx,"lowx":lowx,"uppx":uppx,"predy":predy,"lowy":lowy,"uppy":uppy,"predz":predz,"lowz":lowz,"uppz":uppz,"predp":predp,"lowp":lowp,"uppp":uppp})



def future_prediction_chart_hours_tomorrow(request,group_name):
    group_name=group_name
    print("this is machine name",group_name)

    # return render(request, 'machine.html',{"groupname":group_name})
    return render(request,'futureForcastingHT.html',{"groupname":group_name})


def future_prediction_chart_10(request,group_name):
    group_name=group_name
    timedata=[35,35,35,36,34,36,35,35,35,34,34,31,35,36,37,34,24,32,35,38,37]
    print("this is machine name",group_name)

    # return render(request, 'machine.html',{"groupname":group_name})
    return render(request,'futureForcastingHT10.html',{"groupname":group_name,'timedata':timedata})





# @login_required
def model_save(request):
    if request.method=="POST":
        audio = request.FILES["audio"]
        name = request.POST["name"]
        customer = request.POST["username"]
        print("this is customer name",customer)
        cust_id=User.objects.get(username=customer)
        u_id=cust_id.id
        use_name=User.objects.get(id=u_id)
        print("this is customer name after User model",cust_id)
        audio_file = Mlmodel.objects.create(name=name,file=audio,username=use_name)
        audio_path= audio_file.file.path
        return render(request, "Model_save.html", {"audio_path":audio_path})
        
    return render(request, "Model_save.html")
    
    # sa=Mlmodel.objects.get(name="khan")
    # p=sa.file.path
    # print("this is file name",sa)
    # print("this is file path",p)
    # else:
    #     return render(request, "index.html")





def model_save_time(request):
    if request.method=="POST":
        audio = request.FILES["audio"]
        name = request.POST["name"]
        customer = request.POST["username"]
        size = request.POST["size"]
        print("this is customer name",customer)
        
        cust_id=User.objects.get(username=customer)
        u_id=cust_id.id
        use_name=User.objects.get(id=u_id)
        print("this is customer name after User model",cust_id)
        audio_file = Mlmodel.objects.create(
                                       name=name,
                                       file=audio,
                                       username=use_name,
                                       size=size,
                                      )
        audio_path= audio_file.file.path
        return render(request, "Model_save1.html", {"audio_path":audio_path})
    
    # sa=Mlmodel.objects.get(name="khan")
    # p=sa.file.path
    # print("this is file name",sa)
    # print("this is file path",p)
    return render(request, "Model_save1.html")



def AImodel(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    amomaly=user.mlmodel_set.all()
    time=user.time_model_set.all()
    all_user=User.objects.all()
    context={"time":time,"anomaly":amomaly}
    return render(request, "Models.html",context)
    
    
    
    
    
@login_required
def some_view(request):
    if request.user.is_superuser:
        return render(request, 'app/template1.html')
    else:
        return render(request, 'app/template2.html',)
 
 
 
 
    
def admin_login(request):
    if request.method=="POST":
        form = AuthenticationForm(request,data=request.POST)
        if form.is_valid():
            username=request.POST['username']
            password=request.POST['password']
            user=authenticate(username=username,password=password)
            if user.is_superuser:
                auth.login(request,user)
                context={'orgnization':password,"username":username,}
                # return render(request,'newdes.html')
                return redirect("admin_main")
            else:
                messages.info(request,"Only Admin Can access")

        else:
            messages.error(request,"Invalid username or password.")


    form=AuthenticationForm
    return render(request=request,template_name="login1.html")

def main_admin(request):
    return render(request,"admin_home1.html")


def admin_home(request):
    return render(request,'admin_home.html')


def all_user(request):
    all=User.objects.all()
    return render(request,"All_user.html",{"all":all})

def all_machine(request):
    all_m=Machine.objects.all()
    print(all_m)
    return render(request,"all_machine.html",{"all_m":all_m})

def all_faults(request):
    all_p=Fault_occur.objects.all()
    all_f=Fault_future.objects.all()
    context={"all_p":all_p,"all_f":all_f}
    return render(request,"all_fauls.html",context)





def user_all_machine(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    machine=user.machine_set.all()   
    return render(request,"all_about_machine.html",{"all_user_machine":machine,'user_name':user})






allmachine=["TVS","TVS1"]


def KPI(request):
    
    current=request.user
    id=current.id
    print(id)
    user=User.objects.get(id=id)
    fault=user.fault_occur_set.all()
    all_user=User.objects.all()
    print("clear list",runningmachine)
    print("this is moduls handling",runningmachine)
    print("this is moduls handling",len(runningmachine))
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)    
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    all_ma=user.machine_set.all()
    all_ma_count=user.machine_set.count()
    print("all machine is number",all_ma_count)
    machine_name=[]
    for i in all_ma:
        # print("machine name",i.machine_ID)
        machine_name.append(i.username)
        
    running=list(set(machine_name).intersection(runningmachine))
    print(len(running),machine_name,running)
    nonOK=len(machine_name)-len(runningmachine)
    print("important information",all_ma_count,machine_name,nonOK,running)
    return render(request,"KPI.html",{"all_ma_count":all_ma_count,"machine_name":machine_name,"running":len(running),"NONOK":nonOK})








def alert(request): 
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    all_ma=user.machine_set.all()
    level1=user.level1_set.all()
    level2=user.level2_set.all()
    level3=user.level3_set.all()
    level4=user.level4_set.all()
    print(level1)
    print(level2)
    print(level3)
    print(level4)
    return render(request,"alert.html",{"level1":level1,"level2":level2,"level3":level3,"level4":level4})




def billing(request): 
    return render(request,"billing.html",)






def newfront(request): 
    return render(request,"newfront.html",)


def permission(request):
    all_take=per.objects.all()
    allnew=newuser.objects.all()

    return render(request,"permission.html",{"all_take":all_take,"allnew":allnew})



def takepermission(request):
    all=User.objects.all()
    print("take",all)
    
    if request.method=="POST":
        username=request.POST['aimodel']
        print("this is ",username)
        if per.objects.filter(username=username).exists():
                messages.info(request,"username is already exits")
                return redirect("take")
        else:
            user=per(username=username)
            user.save()
            return redirect(permission)
        
    return render(request,"takepermission.html",{"all":all})


# def per(request):
    
#     return



def givepermission(request):
    all=per.objects.all()
    print("give",all)
    if request.method=="POST":
        username=request.POST['aimodel']
        print("this is ",username)
        per.objects.filter(username=username).delete()
        return redirect(permission)
    
    return render(request,"givepermission.html",{"all":all})




def newuserpermission(request):
    allnew=newuser.objects.all()
    print("give",all)
    if request.method=="POST":
        username=request.POST['aimodel']
        print("this is ",username)
        newuser.objects.filter(username=username).delete()
        return redirect(permission)
    
    return render(request,"newuserpermission.html",{"allnew":allnew})

















def error_404_view(request, exception):
   
    # we add the path to the 404.html file
    # here. The name of our HTML file is 404.html
    return render(request, '404.html')



# def systembase(t,n,x,y,z,v,model):
    
#     if model == "good":
#         if 90<=x and x>=30:
#             pass
            