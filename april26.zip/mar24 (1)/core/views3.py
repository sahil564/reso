from django.shortcuts import render
from django.contrib.auth.models import User
from django.http import HttpResponse
from core.views import *
from core.views2 import *



def Score(request,group_name):
    print(group_name)
    return render(request,"Mhealth.html",{"groupname":group_name})